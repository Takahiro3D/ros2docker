'''
* publisher
*
* Copyright (c) 2020-2021, Magik-Eye Inc.
* author: Jigar Patel, jigar@magik-eye.com
'''

from numpy.core.numeric import False_
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2, PointField
from std_msgs.msg import String
from shape_msgs.msg import Plane
import threading
import time
import pymkeapi
import numpy as np
from pymkeros2.device_info import DeviceInfo
import open3d as o3d

# ============================================================================
# MkEPointCloudPublisher - TODO :Check for thread safe and correct termination

class MkEPointCloudPublisher(Node):
    def __init__(self, device_info):
        self.device_info_ = device_info
        self.publishing_flag_ = False
        self.pub_ = None
        self.pub_plane_ = None
        super().__init__(self.device_info_.getNodeName())

        # Other variables
        self.tcp_bus_ = None
        self.client_ = None
        self.thread_ = None

        rot_s = np.sin(np.pi / 3)
        rot_c = np.cos(np.pi / 3)
        self.rot_m = np.array([[rot_c, 0.0, -rot_s],
                                [0.0, -1.0, 0.0],
                                [-rot_s, 0.0, -rot_c]])

    # =========================================================================

    # Check - Needed ? Calls the function again
    def __del__(self):
        self.stopPublishing()

    # =========================================================================

    def publish(self):
        self.publishing_flag_ = True

        self.pcd = o3d.geometry.PointCloud()
        self.downpcd = o3d.geometry.PointCloud()

        vis = o3d.visualization.Visualizer()
        vis.create_window()

        #o3d.visualization.ViewControl.rotate(0.3, 0.3)

        self.is_init_vis = False

        try:
            while self.publishing_flag_:
                frame = self.client_.get_frame(pymkeapi.MKE_FRAME_TYPE_1)
                ftype = frame.frame_type
                num = frame.pts3d.shape[0]
                pt_size = {1: 8, 2: 12}.get(ftype)
                dim = {1: 4, 2: 6}.get(ftype)

                frame.pts3d = np.dot(frame.pts3d, self.rot_m)

                '''
                for i in range(frame.pts3d.shape[0]):
                    inner_val = frame.pts3d[i,0] * frame.pts3d[i,0] \
                                + frame.pts3d[i,1] * frame.pts3d[i,1] \
                                + frame.pts3d[i,2] * frame.pts3d[i,2]
                    
                    #print(inner_val)
                    if inner_val > 640000:
                        np.delete( frame.pts3d, i, 0)
                '''
                frame.pts3d = 0.001 * frame.pts3d # frame.pts3d(mm) to ROS(m)

                self.pcd.points = o3d.utility.Vector3dVector(frame.pts3d)

                downpcd = self.pcd.voxel_down_sample(voxel_size=0.05)
                self.downpcd.estimate_normals(
                        search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
                self.downpcd.clear()
                self.downpcd, ind = downpcd.remove_statistical_outlier(nb_neighbors=20,
                                                                       std_ratio=2.0)
                #self.downpcd, ind = downpcd.remove_radius_outlier(nb_points=4, radius=0.1)
                downpcd.clear()
                plane_model, inliers = self.downpcd.segment_plane(distance_threshold=0.01,
                                                                  ransac_n=3,
                                                                  num_iterations=1000)
                [a, b, c, d] = plane_model # ax+by+cz+d=0
                plane_ = Plane()
                plane_[0] = a
                plane_[1] = b
                plane_[2] = c
                plane_[3] = d
                #print(a, b, c, d)









































                

                if self.is_init_vis == False:
                    self.is_init_vis = True
                    #vis.add_geometry(self.pcd)
                    vis.add_geometry(self.downpcd)
                    time.sleep(0.1)

                vis.remove_geometry(self.downpcd)
                vis.add_geometry(self.downpcd)
                vis.update_geometry(self.downpcd)
                #vis.update_geometry(self.downpcd)
                #vis.update_geometry(self.pcd)
                vis.poll_events()
                vis.update_renderer()

                data = np.concatenate((frame.pts3d,
                                       frame.uids.reshape(frame.uids.shape[0], 1)), axis=1)
                msg = PointCloud2()
                msg.header.frame_id = 'map'
                msg.height = 1
                msg.width = num
                msg.fields = [
                    PointField(name='x', offset=0,
                        datatype=PointField.FLOAT32, count=1),
                    PointField(name='y', offset=4,
                        datatype=PointField.FLOAT32, count=1),
                    PointField(name='z', offset=8,
                        datatype=PointField.FLOAT32, count=1),
                    PointField(name='uid', offset=12,
                        datatype=PointField.FLOAT32, count=1)
                ]
                msg.is_bigendian = False
                msg.point_step = 16
                msg.row_step = msg.point_step * num
                msg.is_dense = False
                msg.data = np.asarray(data, np.float32).tostring()
                self.pub_.publish(msg)
                self.pub_plane_.publish(plane_)

        except Exception as e:
            self.get_logger().error(f"Error while publishing \
            ({self.device_info_.getUnitId()} : {self.device_info_.getIpAddr()}) \
            : {str(e)}")

        vis.destroy_window()

    # ===========================================================================

    def closeConnection(self):
        # TODO: Check if reset exists. (del vs assiging to None)
        self.client_ = None
        self.tcp_bus_ = None
        self.pub_ = None
        self.pub_plane_ = None

    # ===========================================================================

    def startPublishing(self):
        if self.publishing_flag_:
            return

        try:
            self.tcp_bus_ = pymkeapi.TcpBus(self.device_info_.getIpAddr(),
                                            8888)
            self.client_ = pymkeapi.SyncClient(self.tcp_bus_)

            state = self.client_.get_state()

            if state == pymkeapi.MKE_STATE_IDLE:
                self.client_.set_state(pymkeapi.MKE_STATE_DEPTH_SENSOR)
            elif state != pymkeapi.MKE_STATE_DEPTH_SENSOR:
                self.client_.set_state(pymkeapi.MKE_STATE_IDLE)
                self.client_.set_state(pymkeapi.MKE_STATE_DEPTH_SENSOR)

            # Create topic publisher
            topic_name = self.device_info_.getTopicName()
            self.pub_ = self.create_publisher(PointCloud2, topic_name, 1)
            self.pub_plane_ = self.create_publisher(Plane, 'pymkeros2_node_pln_s1', 1)

        except Exception as e:
            self.closeConnection()
            print(e)

        self.thread_ = threading.Thread(target=self.publish)
        self.thread_.start()

    # ===========================================================================

    def stopPublishing(self):
        if not self.publishing_flag_:
            return

        self.publishing_flag_ = False
        self.thread_.join()

        if not self.client_:
            self.closeConnection()
            return

        state = self.client_.get_state()
        if state != pymkeapi.MKE_STATE_IDLE:
            self.client_.set_state(pymkeapi.MKE_STATE_IDLE)
        self.closeConnection()

    # ===========================================================================

    def getDeviceInfo(self):
        return self.device_info_

    # ===========================================================================

    def setDeviceInfo(self, device_info):
        self.device_info_ = device_info

    # ===========================================================================


if __name__ == "__main__":
    device_info = DeviceInfo("34cff660", "192.168.0.117")

# ===============================================================================
# ===============================================================================

    # Test the constructor
    device_info1 = DeviceInfo()
    mkepub = MkEPointCloudPublisher(device_info1)
    print(mkepub)
    mkepub.setDeviceInfo(device_info)
    print(mkepub.getDeviceInfo())

    # Test start publishing
    mkepub.startPublishing()
    time.sleep(5)

    # Test stop publishing
    mkepub.stopPublishing()
